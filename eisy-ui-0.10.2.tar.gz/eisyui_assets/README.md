Please use UI @/utils/staticAsset to refer to files here
